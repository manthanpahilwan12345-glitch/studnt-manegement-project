# Algorithm Design Document

Smart Library Management System — Unit 2 (plain-language numbered steps, no Python syntax).


## 1. Add a New Book

1. Accept the book's information (ID, title, author, category, ISBN, price) from the user.
2. Check whether a book with the same ID already exists in the collection.
3. If it does not exist, store the new record.
4. If it already exists, reject the entry and warn the user.
5. Display a confirmation message.

## 2. Search for a Book by Title

1. Accept the title to search for.
2. Compare it (ignoring upper/lower case) against every stored record's title.
3. If a match is found, display that record's details and stop searching.
4. If no match is found after checking every record, display "Book Not Found".

## 3. Update Book Details

1. Accept the Book ID to update.
2. Search for the record with that ID.
3. If found, ask which field to update and its new value.
4. Overwrite that field and confirm the update.
5. If not found, display "Book Not Found".

## 4. Remove Duplicate Categories

1. Read the category field from every book record into a list.
2. Convert that list into a set to discard duplicates.
3. Display the unique categories.

## 5. Count Available Books

1. Set a counter to zero.
2. For each book, if its availability is True, increase the counter by one.
3. Display the final count.

## 6. Find Books by Author

1. Accept the author's name.
2. Build a list of every book whose author field matches.
3. If the list is not empty, display all matches.
4. If the list is empty, display "No books found for this author".

## 7. Sort Books Alphabetically

1. Read all book titles into a list.
2. Sort the list alphabetically.
3. Display the sorted list.

## 8. Remove a Book (Withdraw)

1. Accept the Book ID of the book to withdraw.
2. Search the collection for a record with that ID.
3. If found, delete that record from the collection and confirm.
4. If not found, display "Book Not Found".

## 9. Display All Available Books

1. Set a flag showing whether any available book was found to False.
2. Go through every book in the collection.
3. If the book's availability is True, display its details and set the flag to True.
4. After the loop, if the flag is still False, display "No books available".

## 10. Organize Books According to Genre

1. Create an empty dictionary to hold genre -> list of books.
2. For each book, read its category (genre).
3. If the genre is not yet a key in the dictionary, create it with an empty list.
4. Append the book's title to the list for that genre.
5. Display every genre with its list of books.

## 11. Maintain Author Information

1. Create an empty dictionary that maps an author's name to that author's details (e.g. list of titles).
2. Accept an author's name and a book title.
3. If the author is not yet in the dictionary, add the author with an empty list of titles.
4. Append the title to that author's list.
5. Display the author's updated information.

## 12. Borrow / Return a Book (Update Availability)

1. Accept the Book ID and the action (borrow or return).
2. Search for the book with that ID.
3. If not found, display "Book Not Found".
4. If the action is borrow: if the book is available, set available to False; otherwise warn that it is already borrowed.
5. If the action is return: set available to True and confirm.
