# Pseudocode Document

Structured English matching each flowchart in `flowcharts/`.


## 1. Add a New Book

```
START
  READ book details
  IF book ID already exists in collection THEN
     DISPLAY "Book already exists"
  ELSE
     STORE book in collection
     DISPLAY "Book added successfully"
  END IF
STOP
```

## 2. Search for a Book by Title

```
START
  READ title
  SET found = False
  FOR each book in collection
     IF book title matches title (ignore case) THEN
        DISPLAY book details
        SET found = True
        EXIT loop
     END IF
  END FOR
  IF found == False THEN
     DISPLAY "Book Not Found"
  END IF
STOP
```

## 3. Update Book Details

```
START
  READ book_id
  IF book_id exists in collection THEN
     READ field_to_update, new_value
     SET collection[book_id][field_to_update] = new_value
     DISPLAY "Book updated successfully"
  ELSE
     DISPLAY "Book Not Found"
  END IF
STOP
```

## 4. Remove Duplicate Categories

```
START
  CREATE empty list all_categories
  FOR each book in collection
     APPEND book category TO all_categories
  END FOR
  SET unique_categories = SET(all_categories)
  DISPLAY unique_categories
STOP
```

## 5. Count Available Books

```
START
  SET count = 0
  FOR each book in collection
     IF book["available"] == True THEN
        count = count + 1
     END IF
  END FOR
  DISPLAY count
STOP
```

## 6. Find Books by Author

```
START
  READ author_name
  CREATE empty list matches
  FOR each book in collection
     IF book author == author_name THEN
        APPEND book TO matches
     END IF
  END FOR
  IF matches is empty THEN
     DISPLAY "No books found for this author"
  ELSE
     DISPLAY matches
  END IF
STOP
```

## 7. Sort Books Alphabetically

```
START
  CREATE list titles FROM collection
  SORT titles alphabetically
  DISPLAY titles
STOP
```

## 8. Remove a Book (Withdraw)

```
START
  READ book_id
  IF book_id exists in collection THEN
     REMOVE book from collection
     DISPLAY "Book removed successfully"
  ELSE
     DISPLAY "Book Not Found"
  END IF
STOP
```

## 9. Display All Available Books

```
START
  SET any_available = False
  FOR each book in collection
     IF book["available"] == True THEN
        DISPLAY book details
        SET any_available = True
     END IF
  END FOR
  IF any_available == False THEN
     DISPLAY "No books available"
  END IF
STOP
```

## 10. Organize Books According to Genre

```
START
  CREATE empty dictionary genre_books
  FOR each book in collection
     SET genre = book category
     IF genre NOT IN genre_books THEN
        SET genre_books[genre] = empty list
     END IF
     APPEND book title TO genre_books[genre]
  END FOR
  FOR each genre, titles IN genre_books
     DISPLAY genre, titles
  END FOR
STOP
```

## 11. Maintain Author Information

```
START
  READ author_name, title
  IF author_name NOT IN authors THEN
     SET authors[author_name] = empty list
  END IF
  APPEND title TO authors[author_name]
  DISPLAY author_name, authors[author_name]
STOP
```

## 12. Borrow / Return a Book (Update Availability)

```
START
  READ book_id, action
  IF book_id NOT IN collection THEN
     DISPLAY "Book Not Found"
  ELSE IF action == "borrow" THEN
     IF book["available"] == True THEN
        SET book["available"] = False
        DISPLAY "Book borrowed"
     ELSE
        DISPLAY "Book is already borrowed"
     END IF
  ELSE
     SET book["available"] = True
     DISPLAY "Book returned"
  END IF
STOP
```
