# Smart Library Management System — Unit 2 Design Work

Design deliverables (Stages 2–4 of the engineering workflow) for the Python assignment.

| File | Contents |
|---|---|
| `algorithms.md` | Numbered plain-language algorithm for each operation |
| `flowcharts.md` + `flowcharts/*.png` | One flowchart per operation (Graphviz sources in `flowcharts/source/`) |
| `pseudocode.md` | Structured-English pseudocode for each operation |

Operations covered: add book, search by title, update book, remove duplicate categories, count available books, find by author, sort alphabetically, remove book, display available books, organize by genre, maintain author information, borrow/return.
