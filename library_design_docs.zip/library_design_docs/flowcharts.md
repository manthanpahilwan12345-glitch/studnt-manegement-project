# Flowchart Collection

Symbols: green rounded = Start/Stop, blue rectangle = process, yellow diamond = decision.


## 1. Add a New Book

![Add a New Book](flowcharts/01_add_book.png)

## 2. Search for a Book by Title

![Search for a Book by Title](flowcharts/02_search_by_title.png)

## 3. Update Book Details

![Update Book Details](flowcharts/03_update_book.png)

## 4. Remove Duplicate Categories

![Remove Duplicate Categories](flowcharts/04_remove_duplicate_categories.png)

## 5. Count Available Books

![Count Available Books](flowcharts/05_count_available.png)

## 6. Find Books by Author

![Find Books by Author](flowcharts/06_find_by_author.png)

## 7. Sort Books Alphabetically

![Sort Books Alphabetically](flowcharts/07_sort_alphabetically.png)

## 8. Remove a Book (Withdraw)

![Remove a Book (Withdraw)](flowcharts/08_remove_book.png)

## 9. Display All Available Books

![Display All Available Books](flowcharts/09_display_available_books.png)

## 10. Organize Books According to Genre

![Organize Books According to Genre](flowcharts/10_organize_by_genre.png)

## 11. Maintain Author Information

![Maintain Author Information](flowcharts/11_maintain_author_information.png)

## 12. Borrow / Return a Book (Update Availability)

![Borrow / Return a Book (Update Availability)](flowcharts/12_borrow_and_return.png)
